import { NgModule } from "@angular/core";
import { AppComponent } from "./app.component";
import {BrowserModule} from "@angular/platform-browser"
import { FormsModule } from "@angular/forms"
import { HeaderComponent } from "./header.component";
import { ShoppingModule } from "./shopping/shopping.module";
import { HomeComponent, ListComponent, NotFoundComponent, SignInComponent, SignUpComponent, SignOutComponent, ErrorComponent, ExamplesComponent, PipesDemoComponent, SecurityComponent } from "./routes.components";
import { RouterModule } from "@angular/router"
import { HttpClientModule } from "@angular/common/http"
import { SharedModule } from "./shared/shared.module";
import { LoginService } from "./services/login.service";
import { LoginGuard, LoginGuard2 } from "./services/login.guard";
import { ReversePipe } from "./app.pipes";

const appRoutes = [
        {path:"", component: HomeComponent},
        {path:"list", component: ListComponent},
        {path:"signin", component: SignInComponent},
        {path:"signup", component: SignUpComponent},
        {path:"signout", component: SignOutComponent},
        {path:"example", component: ExamplesComponent, children:[
            {path:"pipes", component: PipesDemoComponent},
            {path:"security", component: SecurityComponent}
        ]},
        {path:"error", component: ErrorComponent},
        {path:"**", component: NotFoundComponent}
]

// Decorator NgModule
@NgModule({
    // Register a component
    declarations: [AppComponent, HeaderComponent, HomeComponent, ListComponent, NotFoundComponent, 
        SignInComponent, SignUpComponent, SignOutComponent, ErrorComponent,
        ExamplesComponent, PipesDemoComponent, SecurityComponent, ReversePipe],
    // specify startup component - root component
    bootstrap : [AppComponent],
    // specify module dependencies
    imports: [BrowserModule, FormsModule, ShoppingModule, RouterModule.forRoot(appRoutes, {useHash: true}), 
        HttpClientModule, SharedModule],
    providers: [LoginService, LoginGuard]
})
// Define a class for module
export class AppModule {}