import { Component } from "@angular/core";
import { Product } from "../model/product.model";
import { ProductService } from "../services/product.service";
import { CartService } from "../services/cart.service";
import { CartItem } from "../model/cartItem.model";

@Component({
    selector: "product-list",
    templateUrl: "./product-list.component.html"
})
export class ProductListComponent{
    products: Product[] = [];
    constructor(private cs:CartService, private ps:ProductService) {
        // this.products =  ps.getProducts();
        ps.getProducts().subscribe(
            (data) => this.products = data,
            (error) => console.log("Error", error)
        )
    }

    addToCart(selectedProduct:Product) {
        let item = new CartItem(selectedProduct.name, selectedProduct.price, 1);
        this.cs.addCartItem(item);
    }
}