import { Component } from "@angular/core";
import { CartItem } from "../model/cartItem.model";
import { CartService } from "../services/cart.service";

@Component({
    selector: 'cart-items',
    templateUrl: './cart-items.component.html'
})
export class CartItemsComponent {
    cartItems:CartItem[] = [];
    constructor(private cs:CartService) {
        this.cartItems = cs.getCartItems();
    }

    delete(index:number) {
        this.cs.deleteCartItem(index);
    }

    totalAmount() {
        let tot = 0;
        for(let e of this.cartItems) {
            tot +=  (e.price * e.qty);
        }
        return tot;
    }
}