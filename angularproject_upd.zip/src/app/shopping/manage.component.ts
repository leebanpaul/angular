import { Component } from "@angular/core";
import { ProductService } from "../services/product.service";
import { Product } from "../model/product.model";

@Component({
    templateUrl: "./manage.component.html"
}) 
export class ManageComponent {
    products:Product[] = [];
    frmProduct:Product = new Product(null, null, null, null);

    constructor(private ps:ProductService) {
        // this.products = ps.getProducts();
        // ps.getProducts().subscribe(
        //     (data) => this.products = data,
        //     (error) => console.log("Error", error)
        // )
        this.getAllProducts();
    }

    getAllProducts(){
        this.ps.getProducts().subscribe(
            (data) => this.products = data,
            (error) => console.log("Error", error)
        )
    }

    add() {
        this.ps.addProduct(this.frmProduct).subscribe(
            (data) => {
                console.log("Add Success")
                this.products.push(data);
            }, (err) => {
                console.log("Add Error", err)
            }
        )
        this.frmProduct = new Product(null, null, null, null);
    }

    delete(id:number) {
        this.ps.deleteProduct(id).subscribe(
            (data) => {
                console.log("Delete Success")
                let idx = this.products.findIndex((e) => (e.id == id));
                this.products.splice(idx, 1)
            }, (err) => {
                console.log("Delete Error", err)
            }
        )
    }

    edit(product:Product) {
        Object.assign(this.frmProduct, product);
    }

    update() {
        this.ps.updateProduct(this.frmProduct).subscribe(
            (data) => {
                console.log("Update Success")
                let idx = this.products.findIndex((e) => (e.id == this.frmProduct.id));
                this.products[idx]=data;
               // this.products.push(data);
               this.getAllProducts();
            }, (err) => {
                console.log("Update Error", err)
            }
        )
        this.frmProduct = new Product(null, null, null, null);
    }
}