import { NgModule } from "@angular/core";
import { ProductListComponent } from "./product-list.component";
import { CartItemsComponent } from "./cart-items.component";
import { CommonModule } from "@angular/common";
import { CartService } from "../services/cart.service";
import { ProductService } from "../services/product.service";
import { FormsModule } from "@angular/forms";
import { ManageComponent } from "./manage.component";
import { RouterModule } from "@angular/router";
import { LoginGuard, LoginGuard2 } from "../services/login.guard";

@NgModule({
    declarations: [ProductListComponent, CartItemsComponent, ManageComponent],
    exports:[ProductListComponent, CartItemsComponent],
    imports:[CommonModule, FormsModule, RouterModule.forChild([
        {path: "manage", component: ManageComponent, canActivate: [LoginGuard]}
    ])],
    providers:[CartService, ProductService]
})
export class ShoppingModule {}