import { Component, Input, EventEmitter, Output } from "@angular/core";

@Component({
    selector: "mysign",
    template: `
    <h3>{{title}}</h3>
    <div class="well">
        <input type="text" placeholder="Enter User Name" #frmUser/>
        <input type="password" placeholder="Enter Password" #frmPwd/>
        <button type="button" class="btn btn-primary" 
            (click)="handleButtonClick(frmUser.value, frmPwd.value)">{{title}}</button>
    </div>
    `
})
export class MySignComponent {
    @Input()
    title:string;
    
    @Output()
    myEvent = new EventEmitter();

    handleButtonClick(userName:string, password:string) {
        console.log(userName)
        console.log(password)
        this.myEvent.emit({uname:userName, pwd:password});
    }
}