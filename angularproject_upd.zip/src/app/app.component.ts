import { Component } from "@angular/core";

@Component({
    // Specify tag name for component
    selector : "app-root",
    // output for the component
    templateUrl: "./app.component.html"
})
export class AppComponent {
    // Data member wth Type Annotation
    appHeading:string;
    // Data member with Type Inference
    count = 0;
    constructor() {
        this.appHeading = "My App";
        // this.count = 0;
        // this.count = "aa";

    }
    
    handleButtonClick():void {
        this.appHeading = "BNP, SP infocity"
    }

    incrementCounter() {
        this.count++;
    }
}