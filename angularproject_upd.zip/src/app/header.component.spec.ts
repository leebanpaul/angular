import { TestBed } from "@angular/core/testing";
import { HeaderComponent } from "./header.component";
import { LoginService } from "./services/login.service";
import { ReversePipe } from "./app.pipes";

describe("Verify Header Component", () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [HeaderComponent],
            providers:[LoginService]
        })
    })
    it("should create insance of Header Component", () => {
        let f = TestBed.createComponent(HeaderComponent);        
    })
    it("Should verify cmpHeading in Header Component", () => {
        let f = TestBed.createComponent(HeaderComponent);
        let obj = f.debugElement.componentInstance;
        expect(obj.cmpHeading).toEqual("My Shopping Cart App");
    })
    it("verify reverse pipe",() => {
        let p = new ReversePipe();
        expect(p.transform("ABCD")).toEqual("DCBA");
    })
    it("Verify Login Service", () => {
        let ls = new LoginService();
        expect(ls.isValidUser("admin", "p")).toBeTruthy();
    })
})