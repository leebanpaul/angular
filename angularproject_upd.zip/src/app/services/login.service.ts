import { Injectable } from "@angular/core";

@Injectable()
export class LoginService {

    private isLoggedIn:boolean = false;

    getIsLoggedIn() {
        return this.isLoggedIn;
    }

    setIsLoggedIn(val:boolean) {
        this.isLoggedIn = val;
    }

    isValidUser(username:string, password:string) {
        if (username == "admin") {
            this.setIsLoggedIn(true);
            return true;
        } else {
            return false;
        }
    }

    logout() {
        this.setIsLoggedIn(false);
    }
    
}