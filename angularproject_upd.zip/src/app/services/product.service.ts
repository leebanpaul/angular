import { Product } from "../model/product.model";
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class ProductService {
    private productsData: Product[] = [];
    restUrl = "http://localhost:3000/wsproducts"

    constructor(private http:HttpClient) {
        // this.productsData = [
        //     new Product(1, "Bravia", 55000,"Sony TV"),
        //     new Product(2, "Bose", 44000,"Speaker"),
        //     new Product(3, "Galaxy S", 77000,"Samsung"),
        //     new Product(4, "iPhone X", 155000,"Apple")
        // ]
    }

    getProducts() {
        // return this.productsData;
        return this.http.get<Product[]>(this.restUrl);
    }

    addProduct(newProduct:Product) {
        return this.http.post<Product>(this.restUrl, newProduct);
    }

    deleteProduct(id:number) {
        return this.http.delete(this.restUrl + "/" + id);
    }
    
    updateProduct(product:Product) {
        return this.http.put<Product>(this.restUrl + "/" + product.id, product);
    }
}