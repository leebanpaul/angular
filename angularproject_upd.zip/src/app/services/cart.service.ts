import { CartItem } from "../model/cartItem.model";
import { Injectable } from "@angular/core";

@Injectable()
export class CartService {
    private cartData:CartItem[] = [];

    constructor() {}

    // Add an item to cart
    addCartItem(newItem:CartItem) {

        let isPresent:boolean = false;
        for (let i = 0; i < this.cartData.length; i++) {
            const element = this.cartData[i];
            if (element.name == newItem.name) {
                this.cartData[i].qty++;   
                isPresent = true;             
            }
        }
        if (!isPresent) {
            this.cartData.push(newItem);    
        }
        
    }

    // Remove
    deleteCartItem(idx:number) {
        this.cartData.splice(idx, 1);
    }

    // Get all items
    getCartItems() {
        return this.cartData;
    }
}