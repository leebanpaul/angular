import { Component } from "@angular/core";
import { LoginService } from "./services/login.service";
import { Router } from "@angular/router";
import { DomSanitizer } from "@angular/platform-browser";

@Component({
    template: `<h3>Welcome to My Shopping Cart App</h3>`
})
export class HomeComponent {}

@Component({
    template: `<div class="col-sm-6">
    <product-list></product-list>
</div>
<div class="col-sm-6 well">
     <cart-items></cart-items>
</div>`
})
export class ListComponent {}

@Component({
    template: "<h1 class='well'>404. Page not found.</h1>"
})
export class NotFoundComponent {}

@Component({
    selector: "sign-in",
    template: `<mysign title="Sign In" (myEvent)="handleMyEvent($event)"></mysign>`
})
export class SignInComponent { 


    constructor(private ls:LoginService, private router:Router) {}

    handleMyEvent(obj) {
        // console.log("Sign In : User Name:", obj.uname, " Password:", obj.pwd)
        let isAdmin = this.ls.isValidUser(obj.uname, obj.pwd);
        if (isAdmin) {
            this.router.navigate(["/manage"]);
        } else {
            this.router.navigate(["/error"]);
        }
    }

}

@Component({
    selector: "sign-up",
    template: `<mysign [title]="myTitle" ></mysign>`
})
export class SignUpComponent {
    myTitle = "Quick Sign Up"
}

@Component({
    selector: "sign-out",
    template: "<h4>You have Signed Out...</h4>"
})
export class SignOutComponent {
    constructor(private ls:LoginService) {}
}

@Component({
    template: `<h1>Invalid Credentials!!</h1>`
})
export class ErrorComponent {}

@Component({
    template: `<h1>Angular Examples</h1>
    <div class="col-sm-2 well">
        <ul class="nav navbar-sidebar">
            <li> <a routerLink="pipes">Pipes Demo</a></li>
            <li> <a routerLink="security">Security Demo</a></li>
        </ul>
    </div>
    <div class="col-sm-10">
        <router-outlet></router-outlet>
    </div>
    `
})
export class ExamplesComponent {}

@Component({
    template: `<h3>PipesDemo component
    <br> Price value is {{price | currency:'INR'}}
    <br> Date is {{mydate | date:'dd/MM/yyyy'}}
    <br> Name is {{productName | uppercase | reverseText }}
    `
})
export class PipesDemoComponent {
    price = 100.1234;
    mydate = new Date();
    productName = "sony tv";
}


@Component({
    template: `<h3>Angular Security Example</h3>
    <h4>Untrusted URL</h4>
    <p><a [href]="dangerousUrl">Click Here</a></p>
    <h4>Trusted URL</h4>
    <p><a [href]="safeUrl">Click safe Here</a></p>
    `
})
export class SecurityComponent {
    dangerousUrl = "javascript:alert('Alert Message - BNP, Chennai')"
    safeUrl;
    constructor(private ds:DomSanitizer) {
        this.safeUrl = ds.bypassSecurityTrustUrl(this.dangerousUrl);
    }
}