export class CartItem {
    constructor (public name:string, public price:number, public qty:number) {
        
    }
}