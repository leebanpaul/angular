import { Component } from "@angular/core";
import { LoginService } from "./services/login.service";

@Component({
    selector:"app-header",
    template:`<nav class="navbar navbar-inverse">
        <div class="navbar-header">
            <a href="#" class="navbar-brand">{{cmpHeading}}</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a routerLink="/">Home</a></li>
            <li><a routerLink="/example">Examples</a></li>
            <li><a routerLink="/list">Shopping List</a></li>
            <li *ngIf="isUserLoggedIn()"><a routerLink="/manage">Manage Products</a></li>
            <li *ngIf="!isUserLoggedIn()"><a routerLink="/signin">Sign In</a></li>
            <li *ngIf="!isUserLoggedIn()"><a routerLink="/signup">Sign Up</a></li>
            <li *ngIf="isUserLoggedIn()"><a routerLink="/signout" (click)="logout()">Sign Out</a></li>
        </ul>
    </nav>`
})
export class HeaderComponent {
    cmpHeading = "My Shopping Cart App"

    constructor(private ls:LoginService) {}

    isUserLoggedIn() {
        return this.ls.getIsLoggedIn();
    }

    logout() {
        console.log("I am in Header")
        this.ls.setIsLoggedIn(false);
    }
}